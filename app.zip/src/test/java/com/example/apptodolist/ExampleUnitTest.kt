/**
 * @Author: 
 * @Date: 2024-12-10 22:06:58
 * @LastEditors: 
 * @LastEditTime: 2024-12-10 22:07:30
 * @FilePath: app/src/test/java/com/example/apptodolist/ExampleUnitTest.kt
 * @Description: 这是默认设置,可以在设置》工具》File Description中进行配置
 */
package com.example.apptodolist

import org.junit.Test

import org.junit.Assert.*

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }
}