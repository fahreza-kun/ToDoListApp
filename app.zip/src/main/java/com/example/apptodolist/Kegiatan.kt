package com.example.apptodolist

data class Kegiatan(
    val namaKegiatan: String,
    val targetSelesai: String,
    var selesai: Boolean
)